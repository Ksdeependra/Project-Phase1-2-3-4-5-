package com.capgemini.payment.test;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.payment.beans.Customer;
import com.capgemini.payment.beans.Wallet;
import com.capgemini.payment.exception.ConnectionLostException;
import com.capgemini.payment.exception.InsufficientBalanceException;
import com.capgemini.payment.exception.InvalidMobileNumberException;
import com.capgemini.payment.repository.WalletRepository;
import com.capgemini.payment.repository.WalletRepositoryImpl;
import com.capgemini.payment.service.WalletService;
import com.capgemini.payment.service.WalletServiceImpl;

public class JUnitTest {

	WalletRepository walletRepository;
	WalletService walletService;

	@Before
	public void setUp() throws Exception {
		walletRepository = new WalletRepositoryImpl();
		walletService = new WalletServiceImpl(walletRepository);
	}

	@Test(expected = com.capgemini.payment.exception.InvalidMobileNumberException.class)
	public void whenMobileNumberIsAlreadyUsedForAnyOtherCustomerThenSystemShouldThrowAnException()
			throws InvalidMobileNumberException, ConnectionLostException {
		walletService.createAccount("Vaibhav", "7000000000", new BigDecimal("1000"));
		walletService.createAccount("Vaibhav", "7000000000", new BigDecimal("1000"));
	}

	@Test(expected = com.capgemini.payment.exception.InvalidMobileNumberException.class)
	public void whenMobileNumberIsUsedForShowBalanceIsNotInDatabaseThenSystemShouldThrowAnException()
			throws InvalidMobileNumberException, ConnectionLostException {
		walletService.createAccount("Vaibhav", "7000000002", new BigDecimal("2000"));
		walletService.showBalance("7000000019");
	}

}
